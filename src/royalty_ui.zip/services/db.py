from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from models import Base, engine, SessionLocal

def init_db() -> None:
    """Skapar tabeller om de inte finns."""
    Base.metadata.create_all(bind=engine)

@contextmanager
def get_db() -> Iterator:
    """Context manager för SQLAlchemy-session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
