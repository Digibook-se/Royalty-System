from __future__ import annotations

import io
import os
from dataclasses import asdict
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from openpyxl import Workbook

from models import Author, RoyaltyRun, RoyaltyRunItem, PayoutBatch, PayoutTransaction

# Vi återanvänder er befintliga "motor" från main.py och elib_client.py
from elib_client import fetch_invoice_csv, aggregate
from main import (
    compute_run_plan,
    build_author_lookup,
    load_aliases_prefer_xlsx,
    norm_key,
    period_from_date,
    VAT_RATE,
    PAYOUT_THRESHOLD,
)

OUT_DIR = Path("out")
OUT_DIR.mkdir(exist_ok=True)

def _dec(x: Any) -> Decimal:
    try:
        return Decimal(str(x))
    except Exception:
        return Decimal("0")

def load_inputs_to_env(
    elib_csv_path: str,
    biblio_xlsx_path: Optional[str] = None,
    biblio_from: Optional[str] = None,
    biblio_to: Optional[str] = None,
) -> None:
    """
    För enkelhet återanvänder vi er existerande importkod som läser från env-variabler.
    """
    os.environ["LOCAL_CSV"] = str(elib_csv_path)

    if biblio_xlsx_path:
        os.environ["BIBLIO_FILE"] = str(biblio_xlsx_path)
        if biblio_from:
            os.environ["BIBLIO_FROMDATE"] = str(biblio_from)
        if biblio_to:
            os.environ["BIBLIO_TODATE"] = str(biblio_to)
    else:
        # Om du kör utan biblio vill vi inte råka ha kvar gamla env-värden
        os.environ.pop("BIBLIO_FILE", None)
        os.environ.pop("BIBLIO_FROMDATE", None)
        os.environ.pop("BIBLIO_TODATE", None)

def analyze_run(
    db,
    excluded_authors_raw: str = "",
    alias_xlsx_path: Optional[str] = None,
    alias_csv_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Bygger en RunPlan och returnerar data som UI kan visa.
    """
    # 1) författare från DB
    authors = db.query(Author).all()
    author_lookup = build_author_lookup(authors)

    # 2) alias
    # Om du har en alias-xlsx i repo/fil, sätt den här. Annars faller vi tillbaka till main.py default paths.
    aliases = load_aliases_prefer_xlsx(
        xlsx_path=alias_xlsx_path or "author_aliases.xlsx",
        csv_path=alias_csv_path or "author_aliases.csv",
    )
    alias_email_map = {norm_key(k): v for k, v in aliases.items()}

    # 3) data från eLib (+ ev biblio) via er importer
    df = fetch_invoice_csv()
    if "ToDate" not in df.columns:
        raise KeyError("CSV saknar kolumnen 'ToDate' – kan inte avgöra period")

    # period: ta senaste ToDate
    to_series = df["ToDate"].astype(str).str.strip()
    to_series = to_series[to_series.notna()]
    to_series = to_series[to_series != ""]
    to_series = to_series[to_series.str.lower() != "nan"]
    if len(to_series) == 0:
        raise ValueError("ToDate saknar giltiga datum efter filtrering (tomt eller nan)")

    to_date = to_series.sort_values().iloc[-1]
    period_dt = datetime.fromisoformat(to_date)
    period_key, period_label = period_from_date(period_dt)

    # agg
    agg_df = aggregate(df)

    # excluded
    excluded_keys = set()
    excluded_list = []
    if excluded_authors_raw.strip():
        excluded_list = [p.strip() for p in excluded_authors_raw.strip().strip('"').strip("'").split(";") if p.strip()]
        excluded_keys = {norm_key(x) for x in excluded_list if x}

    # plan
    run_plan = compute_run_plan(
        db=db,
        agg_df=agg_df,
        author_lookup=author_lookup,
        alias_email_map=alias_email_map,
        excluded_keys=excluded_keys,
        period_key=period_key,
    )
    run_plan.period_label = period_label

    # Gör en DataFrame för UI-tabell
    rows = []
    for item in run_plan.items:
        a = item.author
        rows.append({
            "author_id": a.id,
            "author_name": a.name,
            "email": a.email,
            "iban": a.bank_account,
            "prev_balance": float(item.prev_balance),
            "today_share": float(item.today_share),
            "payout_ex_vat": float(item.payout_ex_vat),
            "vat_amount": float(item.vat_amount),
            "payout_inc_vat": float(item.payout_inc_vat),
            "new_balance": float(item.new_balance),
            "will_payout": bool(item.will_payout),
            "vat_rate": float(item.vat_rate),
        })
    items_df = pd.DataFrame(rows).sort_values(["will_payout", "payout_inc_vat"], ascending=[False, False])

    summary = {
        "period_key": period_key,
        "period_label": period_label,
        "num_items": len(run_plan.items),
        "num_missing": len(run_plan.missing_names),
        "num_already_run": len(run_plan.already_run_names),
        "num_excluded_in_csv": len(run_plan.excluded_in_csv),
        "total_payout_inc_vat": float(items_df.loc[items_df["will_payout"] == True, "payout_inc_vat"].sum()) if len(items_df) else 0.0,
        "num_will_payout": int(items_df["will_payout"].sum()) if len(items_df) else 0,
        "num_missing_iban": int(items_df["iban"].isna().sum()) if len(items_df) else 0,
    }

    return {
        "df_raw": df,
        "agg_df": agg_df,
        "run_plan": run_plan,
        "items_df": items_df,
        "summary": summary,
        "excluded_list": excluded_list,
    }

def approve_run_plan(
    db,
    run_plan,
    period_key: str,
    period_label: str,
    vat_rate: Decimal = VAT_RATE,
    payout_threshold: Decimal = PAYOUT_THRESHOLD,
) -> int:
    """
    Skapar RoyaltyRun + RoyaltyRunItem (snapshot av runplan) i DB.
    """
    run = RoyaltyRun(
        period=period_key,
        period_label=period_label,
        vat_rate=_dec(vat_rate),
        payout_threshold=_dec(payout_threshold),
    )
    db.add(run)
    db.flush()  # får run.id

    for item in run_plan.items:
        a = item.author
        ri = RoyaltyRunItem(
            run_id=run.id,
            author_id=a.id,
            author_name=a.name,
            author_email=a.email,
            bank_account_snapshot=a.bank_account,
            vat_registered=bool(a.vat_registered),
            vat_number=a.vat_number,
            prev_balance=_dec(item.prev_balance),
            today_share=_dec(item.today_share),
            payout_ex_vat=_dec(item.payout_ex_vat),
            vat_amount=_dec(item.vat_amount),
            payout_inc_vat=_dec(item.payout_inc_vat),
            new_balance=_dec(item.new_balance),
            will_payout=bool(item.will_payout),
        )
        db.add(ri)

    db.commit()
    return int(run.id)

def create_payout_batch_for_run(db, run_id: int) -> int:
    """
    Skapar PayoutBatch + PayoutTransaction för alla run_items som will_payout=True.
    Blockar transaktioner som saknar IBAN.
    """
    run = db.query(RoyaltyRun).filter(RoyaltyRun.id == run_id).first()
    if not run:
        raise ValueError(f"Hittar ingen RoyaltyRun med id={run_id}")

    items = db.query(RoyaltyRunItem).filter(
        RoyaltyRunItem.run_id == run_id,
        RoyaltyRunItem.will_payout == True,
    ).all()

    batch = PayoutBatch(
        run_id=run_id,
        period=run.period,
        currency="SEK",
        total_amount=Decimal("0"),
        num_transactions=0,
        status="created",
    )
    db.add(batch)
    db.flush()

    total = Decimal("0")
    n = 0

    for it in items:
        author = db.query(Author).filter(Author.id == it.author_id).first()
        creditor_iban = (author.bank_account or "").replace(" ", "") if author else ""
        status = "pending"
        block_reason = None
        if not creditor_iban:
            status = "blocked"
            block_reason = "Saknar IBAN i databasen"

        amount = _dec(it.payout_inc_vat)
        total += amount
        n += 1

        end_to_end_id = f"RUN{run_id}-A{it.author_id}"
        tx = PayoutTransaction(
            batch_id=batch.id,
            author_id=it.author_id,
            creditor_name=it.author_name,
            creditor_email=it.author_email,
            creditor_iban=creditor_iban or None,
            amount=amount,
            end_to_end_id=end_to_end_id,
            status=status,
            block_reason=block_reason,
        )
        db.add(tx)

    batch.total_amount = total
    batch.num_transactions = n
    db.commit()
    return int(batch.id)

def export_blocked_xlsx_bytes(db, batch_id: int) -> bytes:
    """
    Skapar en enkel Blocked.xlsx (för transaktioner med status=blocked) och returnerar filinnehåll som bytes.
    """
    txs = db.query(PayoutTransaction).filter(
        PayoutTransaction.batch_id == batch_id,
        PayoutTransaction.status == "blocked",
    ).all()

    wb = Workbook()
    ws = wb.active
    ws.title = "Blocked"

    ws.append(["author_id", "creditor_name", "creditor_email", "creditor_iban", "amount", "reason"])

    for t in txs:
        ws.append([
            t.author_id,
            t.creditor_name,
            t.creditor_email,
            t.creditor_iban,
            float(t.amount),
            t.block_reason,
        ])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()

def export_bookkeeping_csv_bytes(db, run_id: int) -> bytes:
    """
    Minimal bokföringsunderlag som CSV (MVP).
    Du kan byta till ert befintliga bokföringsunderlag om ni redan har det i main.
    """
    items = db.query(RoyaltyRunItem).filter(RoyaltyRunItem.run_id == run_id).all()
    rows = []
    for it in items:
        rows.append({
            "run_id": run_id,
            "author_id": it.author_id,
            "author_name": it.author_name,
            "payout_ex_vat": float(it.payout_ex_vat),
            "vat_amount": float(it.vat_amount),
            "payout_inc_vat": float(it.payout_inc_vat),
            "will_payout": bool(it.will_payout),
        })
    df = pd.DataFrame(rows)
    return df.to_csv(index=False).encode("utf-8")

def export_pain001_path(batch_id: int) -> Path:
    """
    Återanvänder er exporter (export_pain001.py) genom att importera funktionen vi behöver.
    Exportern i ert repo skriver till out/ och returnerar filnamn via DB.
    Här anropar vi en intern funktion (build_xml) saknas i scriptet, så vi kör scriptets main-liknande funktion.
    """
    # Vi importerar modul och använder dess generate()-funktion om den finns,
    # annars kör vi den modulens "main-style" genom att kalla en hjälpfunktion.
    import export_pain001_ui as p

    # export_pain001.py har ingen "generate" i dagsläget, men har "build_pain001_xml" i koden?
    # Vi tar en säker väg: kalla p.export_batch_to_file(batch_id) om den finns,
    # annars fall back: återskapa minimal export här.
    if hasattr(p, "export_batch_to_file"):
        return Path(p.export_batch_to_file(batch_id))

    # Fallback: använd deras build_* om det finns.
    if hasattr(p, "build_pain001_xml"):
        xml_str = p.build_pain001_xml(batch_id)
        out_path = OUT_DIR / f"pain001_batch_{batch_id}.xml"
        out_path.write_text(xml_str, encoding="utf-8")
        return out_path

    # Sista fallback: kör deras CLI-funktion via ett minimalt "subprocess"-anrop hade varit möjligt,
    # men i MVP gör vi hellre tydligt fel.
    raise RuntimeError(
        "Hittar ingen export-funktion i export_pain001.py. "
        "Lägg gärna till en funktion 'export_batch_to_file(batch_id) -> str' "
        "så kan UI:t anropa den direkt."
    )
